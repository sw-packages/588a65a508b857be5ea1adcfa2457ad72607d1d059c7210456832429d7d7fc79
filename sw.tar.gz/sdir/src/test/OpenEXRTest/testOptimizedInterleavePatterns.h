//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Weta Digital, Ltd and Contributors to the OpenEXR Project.
//

#ifndef _TEST_OPTIMIZED_INTERLEAVE_PATTERNS_
#define _TEST_OPTIMIZED_INTERLEAVE_PATTERNS_

void testOptimizedInterleavePatterns (const std::string &tempDir);

#endif
