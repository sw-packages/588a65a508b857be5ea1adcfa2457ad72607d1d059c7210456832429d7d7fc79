//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.
//

#ifndef TESTINPUTPART_H_
#define TESTINPUTPART_H_

#include <string>

void testInputPart (const std::string & tempDir);

#endif /* TESTINPUTPART_H_ */
